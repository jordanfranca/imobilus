<?php
	abstract class Page {
		public abstract function index();
		public abstract function error();
	}