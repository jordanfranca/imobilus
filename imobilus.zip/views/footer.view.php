<footer class="large-12 medium-12 small-12 left" id="footer-main">
	<div class="row">
		<div class="large-8 large-centered medium-8 medium-centered small-12 small-uncentered columns">
			<div id="content-footer">
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ut maximus justo, nec auctor leo. Proin arcu ligula, venenatis ac purus eget, volutpat hendrerit lectus.
			</div>
				<div id="sociais-footer">
					<ul>
						<li><a id="facebook-footer" href=""></a></li>
						<li><a id="twitter-footer" href=""></a></li>
						<li><a id="youtube-footer" href=""></a></li>
						<li><a id="plus-footer" href=""></a></li>
						<li><a id="mail-footer" href=""></a></li>
					</ul>
				</div>
		</div>		
	</div>
</footer>

<section class="large-12 medium-12 small-12 left" id="signature">
</section>


<script>
$(document).ready(function() {
	$(document).foundation();
});
</script>
	</body>
</html>