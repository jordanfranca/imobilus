
	require('views/cadastro/cadastro.view.php');