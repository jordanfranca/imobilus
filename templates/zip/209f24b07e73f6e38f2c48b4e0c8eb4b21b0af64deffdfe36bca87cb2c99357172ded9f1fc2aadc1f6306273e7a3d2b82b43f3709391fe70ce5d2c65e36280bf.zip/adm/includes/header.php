<div id="header">
		<div class="alinha-centro">
			<div id="logo">
				<a href="../index.php"><img src="img/logo-extremes.png" /></a>
			</div>
			<div id="curtir-top">
				<iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FAgenciaExtremes&amp;width=110&amp;height=2&amp;colorscheme=light&amp;layout=button_count&amp;action=like&amp;show_faces=false&amp;send=false&amp;appId=219634854836330" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:110px; height:21px;" allowTransparency="true">
				</iframe>
				<span class="marrom-c">pessoas já curtiram!</span> <span class="cinza-b">E Você?</span>
			</div>
		</div>
	</div>