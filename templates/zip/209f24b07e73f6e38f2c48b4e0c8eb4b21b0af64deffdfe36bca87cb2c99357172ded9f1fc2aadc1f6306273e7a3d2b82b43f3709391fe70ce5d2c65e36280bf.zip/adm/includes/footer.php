<div id="footer">
		<div class="alinha-centro">
			<div id="assinatura">
				Criado e Desenvolvido por Devisual - Design Visual
			</div>
		</div>
	</div>