<div id="base-busca">
				<form>
					<input id="input-buscar" type="text" value="Pesquisar" name="buscar" />
					<input type="submit" id="buscar" value="" />
				</form>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="../index.php">HOME</a>
				</div>
				<div class="selecionado">
					<img src="img/xbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="../aempresa.php">A EMPRESA</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="../blogs.php">BLOG</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="../servicos.php">SERVIÇOS</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="../clientes.php">CLIENTES</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="../contato.php">CONTATO</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<br /><br />
			<div class="base-menu">
				<div class="txt-link">
					FACEBOOK
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FAgenciaExtremes&amp;width=184&amp;height=350&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=true&amp;appId=219634854836330" scrolling="no" frameborder="0" style="border:none;background:#FFF; overflow:hidden; width:184px; height:350px;" allowTransparency="true"></iframe>
		