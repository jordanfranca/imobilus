			<div class="base-menu">
				<div class="txt-link">
					<a href="painel.php">PAINEL</a>
				</div>
				<div class="selecionado">
					<img src="img/xbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="painel.php">INSERIR ITENS</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="lista.php?ac=posts">LISTA DE POSTS</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="lista.php?ac=clientes">LISTA DE CLIENTES</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			<div class="base-menu">
				<div class="txt-link">
					<a href="logout.php">LOGOUT</a>
				</div>
				<div class="selecionado">
					<img src="img/menosbtn.png" />
				</div>
				<div class="clear"></div>
			</div>
			<div class="barra-separatoria"></div>
			
			
		