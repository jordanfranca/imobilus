<div id="footer">
		<div class="alinha-centro">
			<ul>
				<li>
					<div class="titulo-footer">//CONHEÇA NOSSA <br />AGÊNCIA</div>
					A Extremes foi criada em 2010 em Peruíbe, e é uma empresa inovadora no Litoral Sul.<br /><br />
					Além de ser uma Agência de Publicidade é também uma Empresa de Comunicação Visual.<br /><br />

					<a href="aempresa.php">Leia mais</a>
				</li>
				<li>
					<div class="titulo-footer">//ONDE ESTAMOS</div>
					Nosso endereço físico é em Peruíbe, na
					Rua Prof.ª Rosa Emília Neves Costa, 75, Loja 01.
					Mas atendemos onde você precisar.
					<br /><br />
					Ligue para nós: 13 3453-1254
					<br /><br />
					Você ainda encontra a gente no:<br /><br />
					<a href="http://www.facebook.com/AgenciaExtremes" target="_blank">- Facebook</a><br />
					<a href="http://www.youtube.com/user/AgenciaExtremes/videos" target="_blank">- Youtube</a>
				</li>
				<li class="semmargem">
					<a href="http://www.devisual.com.br" target="_blank"><img src="img/logo_devisual.png" /></a>
				</li>
			</ul>
		</div>
	</div>