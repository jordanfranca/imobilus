<html>
<head>
<STYLE TYPE="text/css">

@font-face {
font-family: NasalizationTeste;
font-style: normal;
font-weight: normal;
src: url(AVGARDN.ttf);
}
@font-face {
font-family: NeuropolTeste;
font-style: normal;
font-weight: normal;
src: url(NEUROPO0.eot);
}
@font-face {
font-family: AcknowledgeTeste ;
font-style: normal;
font-weight: normal;
src: url(ACKNOWL0.eot);
}

p {
	font-family: NasalizationTeste;
}

-->
</STYLE>
<title>P�gina de teste</title>
</head>
<body>
<p>
Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
</p>
<p>
<font size=4 face="NeuropolTeste">
Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
</font>
</p>
<p>
<font size=4 face="AcknowledgeTeste">
Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
</font>
</p>
</body>
</html>